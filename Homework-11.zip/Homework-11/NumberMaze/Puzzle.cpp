#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <cstring>

class PuzzleBoard
{
private:
    std::vector<std::set<int>> edges;
    std::vector<std::vector<int>> fields;
    int numNodes;
    int Bsize;
    int curX, curY;

public:
    int getNode(int i, int j)
    {
        return (this->Bsize * i + j);
    };
    bool CheckBounds(int i, int j)
    {
        if (i >= this->Bsize || i < 0 || j >= this->Bsize || j < 0)
        {
            return false;
        }
        return true;
    };
    PuzzleBoard(int boardSize, int **fields = NULL)
    {
        this->Bsize = boardSize;
        this->numNodes = Bsize * Bsize;
        curX = 0;
        curY = 0;

        // If the table / Puzzle is empty we fill the table fields / Nodes with
        // random values within the range of boardsize
        if (fields == NULL)
        {
            srand(time(0));
            fields = new int *[boardSize];
            if (fields == NULL)
            {
                std::cout << "Error allocating the memory" << std::endl;
                exit(1);
            }
            for (int i = 0; i < boardSize; i++)
            {
                fields[i] = new int[boardSize];
                if (fields[i] == NULL)
                {
                    std::cout << "Error allocating the memory" << std::endl;
                    exit(1);
                }
            }
            for (int i = 0; i < boardSize; i++)
            {
                for (int j = 0; j < boardSize; j++)
                {
                    fields[i][j] = rand() % boardSize + 1;
                }
            }
        }
        else
        {
            this->fields.resize(this->Bsize, std::vector<int>(boardSize));
            for (int i = 0; i < boardSize; i++)
            {
                for (int j = 0; j < boardSize; j++)
                {
                    this->fields[i][j] = fields[i][j];
                }
            }
        }

        //Setting the possible paths/edges from and to a point/field
        edges.resize(numNodes, std::set<int>());
        for (int i = 0; i < boardSize; i++)
        {
            for (int j = 0; j < boardSize; j++)
            {
                int currentNode = getNode(i, j);
                if (CheckBounds(i + fields[i][j], j))
                {
                    edges[currentNode].insert(getNode(i + fields[i][j], j));
                }
                if (CheckBounds(i - fields[i][j], j))
                {
                    edges[currentNode].insert(getNode(i + fields[i][j], j));
                }
                if (CheckBounds(i, j + fields[i][j]))
                {
                    edges[currentNode].insert(getNode(i + fields[i][j], j));
                }
                if (CheckBounds(i, j - fields[i][j]))
                {
                    edges[currentNode].insert(getNode(i + fields[i][j], j));
                }
            }
        }
    };

    bool makeMove(int direction)
    {
        int newx, newy, current, next;
        std::set<int>::iterator pos;

        if (direction == 0)
        {
            newx = this->curX - fields[curX][curY];
            newy = this->curY;
        }
        else if (direction == 1)
        {
            newx = this->curX;
            newy = this->curY + fields[curX][curY];
        }
        else if (direction == 2)
        {
            newx = this->curX + fields[curX][curY];
            newy = this->curY;
        }
        else if (direction == 3)
        {
            newx = this->curX;
            newy = this->curY - fields[curX][curY];
        }

        // Modifying the current position accordingly
        if (CheckBounds(newx, newy))
        {
            return false;
        }
        current = getNode(curX, curY);
        next = getNode(newx, newy);
        pos = edges[current].find(next);
        if (pos == edges[current].end())
        {
            return false;
        }
        this->curX = newx;
        this->curY = newy;
    };

    // Returning the current result according to the position
    bool getResult()
    {
        if (this->Bsize - 1 == this->curX && this->Bsize - 1 == this->curY)
        {
            return true;
        }
        return false;
    };

    friend std::ostream &operator<<(std::ostream &os, const PuzzleBoard &m)
    {
        for (int i = 0; i < m.Bsize; i++)
        {
            for (int j = 0; j < m.Bsize; j++)
            {
                os << m.fields[i][j] << " ";
            }
            os << std::endl;
        }
        return os;
    };

    // Method to solve the Puzzle
    int solve()
    {

        int dis[this->numNodes];
        memset(dis, -1, sizeof(dis));
        std::queue<int> que;
        dis[0] = 0;
        que.push(0);
        while (!que.empty())
        {

            int curr = que.front();
            que.pop();

            for (auto next : edges[curr])
            {
                if (dis[next] == -1)
                {
                    dis[next] = dis[curr] + 1;
                    que.push(next);
                }
            }
        }

        if (dis[numNodes - 1] == -1)
        {
            std::cout << "Solution not found \n";
            exit(0);
        }
        return dis[numNodes];
    };
};

int main(int argc, char **argv)
{
    PuzzleBoard a(4);

    return 0;
}