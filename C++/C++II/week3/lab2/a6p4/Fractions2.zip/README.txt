
make all for all tests

make test-arithmetic for arithmetic test
make test-relational for relational test
make test-IO for Input Output test
make test-exception for exception testing
